import java.util.Random;
/**
 * The RandomPlayer class models a Tic-Tac-Toe playing strategy in which
 * moves are selected randomly from the open spaces on the board.
 *
 * @author Abby McLeran and Cade Christopherson
 * @version 1.0
 */
public class RandomPlayer extends Player
{
    private Random rng = new Random();
    /**
     * The constructor takes the same arguments as the Player constructor
     * does. It invokes the Player constructor, passing along the arguments,
     * then creates our random-number generator.
     * 
     * @param symbol  One of the player constants from the Board class.
     * @param name  The player's name.
     */
    public RandomPlayer (int symbol, String name){
        super(symbol, name);
        Random rng = new Random();
    }

    /**
     * This method selects randomly from among the open positions on the
     * board. If no spaces are open, it runs forever.
     * 
     * @param theBoard The board that the player is making a move on.
     */
    public void makeMove (Board theBoard){
        int col = rng.nextInt(3);
        int row = rng.nextInt(3);
        while (!theBoard.isOpen(col, row)){
            col = rng.nextInt(3);
            row = rng.nextInt(3);
        }
        theBoard.fillPosition(col, row, symbol);
    }
}
