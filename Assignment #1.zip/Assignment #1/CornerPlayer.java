
/**
 * The CornerPlayer class models a Tic-Tac-Toe playing strategy in which open
 * corners are taken first. If no corners are available, it selects randomly
 * from among the open spaces on the board.
 *
 * @author Abby McLeran and Cade Christopherson
 * @version 1.0
 */
public class CornerPlayer extends RandomPlayer
{
    /**
     * The constructor takes the same arguments as the RandomPlayer
     * constructor does, and does nothing more than invoke the RandomPlayer
     * constructor and pass along the arguments.
     * 
     * @param symbol  One of the player constants from the Board class.
     * @param name  The player's name.
     */
    public CornerPlayer (int symbol, String name){
        super(symbol, name);
    }
    
    /**
     * This method looks first for unfilled corner positions on the board. If
     * no corners are available, it selects randomly from among the open
     * spaces on the board.
     * 
     * @param theBoard The board that the player is making a move on.
     */
    public void makeMove (Board theBoard){
        if (theBoard.isOpen(0, 2)) {
            theBoard.fillPosition(0, 2, symbol);
        }
        else {
            if (theBoard.isOpen(0, 0)) {
                theBoard.fillPosition(0, 0, symbol);
            }
            else {
                if (theBoard.isOpen(2, 0)){
                    theBoard.fillPosition(2, 0, symbol);
                }
                    else {
                        if (theBoard.isOpen (2, 2)){
                            theBoard.fillPosition(2, 2, symbol);
                        }
                            else {
                                super.makeMove(theBoard);
                            }
                        }
                    }
            }
        }
    }
