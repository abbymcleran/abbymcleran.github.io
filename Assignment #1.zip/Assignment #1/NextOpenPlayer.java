
/**
 * The NextOpenPlayer class models a Tic-Tac-Toe playing strategy in which
 * the first open space is selected on each move, starting at the top left
 * corner and searching the top row first, then the middle, and finally the
 * bottom row. If no open positions are found, no move is made.
 *
 * @author Abby McLeran and Cade Christopherson
 * @version 1.0
 */
public class NextOpenPlayer extends Player
{
    /**
     * The constructor takes the same arguments as the Player constructor
     * does, and does nothing more than invoke the Player constructor and
     * pass along the arguments.
     * 
     * @param symbol  One of the player constants from the Board class.
     * @param name  The player's name.
     */
    public NextOpenPlayer (int symbol, String name){
        super(symbol, name);
    }

    /**
     * This method selects the first open space it encounters. It searches
     * the board from the top left corner, and looks left to right through
     * the first row, then the middle, and finally the third row. If no open
     * positions are found, no move is made.
     * 
     * @param theBoard The board that the player is making a move on.
     */
    public void makeMove (Board theBoard){
        int col = 0;
        int row = 2;
        while (!theBoard.isOpen(col, row)){
            if (col <= 1){
                col = col+1;
            }
            else{
                col = 0;
                row = row-1;
            }
        }
        theBoard.fillPosition(col, row, symbol);
    }
}