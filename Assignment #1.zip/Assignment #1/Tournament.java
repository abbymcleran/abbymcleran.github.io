
/**
 * The Tournament class provides a static method for playing a game of
 * Tic-Tac-Toe between two player instances.
 *
 * @author Abby McLeran and Cade Christopherson
 * @version 1.0
 */
public class Tournament
{
    public Tournament() {
    }

    /**
     * This method takes two player instances to play a single game of
     * Tic-Tac-Toe between them.
     * 
     * @param one The player instance playing as X.
     * @param two The player instance playing as O.
     * @return The winning player, or null if it's a draw.
     */
    public static Player playGame(Player playerX, Player playerO) {
        Board theBoard = new Board();
        playerX.setSymbol(Board.X);
        playerO.setSymbol(Board.O);
        while (!theBoard.boardFilled()){
            playerX.makeMove(theBoard);
            if (theBoard.getWinner() != -1){
                System.out.println (playerX.celebrate());
                System.out.println (playerO.mourn());
                return playerX;
            }
            playerO.makeMove(theBoard);
            if (theBoard.getWinner() != -1){
                System.out.println (playerO.celebrate());
                System.out.println (playerX.mourn());
                return playerO;
            }
        }
        return null;
    }
}
