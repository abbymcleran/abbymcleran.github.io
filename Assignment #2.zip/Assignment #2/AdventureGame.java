import java.util.Random;

/**
 * This class models a super lame game called "lost in the dark".  You're
 * in charge of moving a character in a dark cave until he or she stumbles
 * across the flashlight.  We pick some random coordinates for the flashlight,
 * and let the user click buttons and move until they've landed on the 
 * flashlight.  The function button provides hints, thankfully.
 * 
 * @author Brad Richards
 * @version 1.0
 */
public class AdventureGame implements Controllable {

    protected Random rand = new Random();
    protected int xWin = rand.nextInt(5);	// Location of the flashlight
    protected int yWin = rand.nextInt(5);
    public int xPos = 0;			// Our location in the grid
    public int yPos = 0;
    
    // We pick one of these strings to display at random when the player moves unsuccessfully
    protected String[] badNews = {"Nope","Not yet", "Try again", "Bummer", "Man it's dark", "No joy"};
    
    // Store our current status in this variable, and return it whenever anyone wants to
    // see our toString() output.  The controller calls toString() after each button press.
    protected String display = "Welcome to Lost in the Dark! Good luck trying to find the flashlight...";

    public AdventureGame() {
        System.out.println("(Don't tell anyone, but the flashlight's at "+xWin+","+yWin+")");
    }
    
    
    /**
     * These four methods control our movements.  To avoid duplicating code,
     * I put all of the move-and-see-if-we-won stuff in movementHelper, and
     * call it from each of the movement methods.
     */
    public void up() {
        movementHelper(0,1);
    }

    public void left() {
        movementHelper(-1,0);
    }

    public void right() {
        movementHelper(1,0);
    }

    public void down() {
        movementHelper(0,-1);
    }

    /**
     * In our game, this special button requests a hint.  The code below is a bit
     * convoluted, but it produces a string that tells the player which direction
     * they need to go to get to the flashlight.
     */
    public void function() {
        String yHint = (yWin > yPos) ? "ahead of" : "behind";  // Conditional operator!
        String xHint = (xWin > xPos) ? "right" : "left";
        if (xWin == xPos) {
            if (yWin == yPos) {
                display = "No need for a hint. You're standing on it.";
            }
            else {
                display = "It's "+yHint+" you";
            }
        }
        else {
            if (yWin == yPos) {
                display = "It's to the "+xHint+" of you";
            }
            else {
                display = "It's "+yHint+" you and to the "+xHint;
            }
        }
    }

    /**
     * This helper carries out a move with specified change in x and y position.
     * It checks to see if we landed on the location of the flashlight, and sets
     * the display string to announce that the player has found it, or randomly
     * selects a bad news string.  (We don't print these to the screen, but the
     * controller will call our toString after each button press so it won't be
     * long before the display string ends up displayed on the controller.)
     * 
     * @param deltaX  How far we've moved horizontally
     * @param deltaY  How far we've moved vertically
     */
    private void movementHelper(int deltaX, int deltaY) {
        xPos = xPos + deltaX;
        yPos = yPos + deltaY;	
        if (xPos == xWin && yPos == yWin) {
            display = "You stumbled across the flashlight!!!";
        }
        else {
            display = badNews[rand.nextInt(badNews.length)];
        }
    }

    /**
     * Return the current display string.
     */
    public String toString() {
        return display;
    }

}
