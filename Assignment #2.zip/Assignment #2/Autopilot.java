
/**
 * This class is an automatic search tool that can "pilot" any object that
 * implements the Controllable interface and look for a designated search term.
 *
 * @author Sumneet Brar and Abby McLeran
 * @version 1.0
 */
public class Autopilot
{
    /**
     * This static method does a methodical search, checking the toString()
     * results for each position. If the toString() result contains the search
     * term, the method should print where the string was found and then return.
     * If the entire search space has been investigated without success, it
     * should print a message reporting failure.
     * 
     * @param c The object that the search is being run on.
     * @param term The search term you are looking for.
     * @param width The width of the grid that is being searched.
     * @param height The height of the grid that is being searched.
     */
    public static String find (Controllable c, String term, int width, int height){
        for (int yPos = 0; yPos < height; yPos += 2){
            for (int xPos = 0; xPos < width; xPos++){
                if (c.toString().contains(term)){
                    System.out.println("Found it at " + xPos + ", " + yPos + ": 'You stumbled across the flashlight!!!'");
                    return "Found it at " + xPos +","+ yPos + ": 'You stumbled across the flashlight!!!'";
                }
                else{
                    c.right();
                }
                System.out.println(xPos + ", " + yPos);
            }
            c.up();     
            for (int xPos = width-1; xPos >= 0; xPos--){
                if (c.toString().contains(term)){
                    System.out.println("Found it at " + xPos + ", " + yPos + ": 'You stumbled across the flashlight!!!'");
                    return "Found it at " + xPos +","+ yPos + ": 'You stumbled across the flashlight!!!'";
                }
                else{
                    c.left();
                }
                System.out.println(xPos + ", " + yPos);
            }
            c.up();
        }
        return "AutoPilot did not find" + term;
    }
}
