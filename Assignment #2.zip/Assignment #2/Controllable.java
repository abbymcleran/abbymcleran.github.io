/**
 * The Controllable interface lists the five methods that a class must
 * implement to be considered "Controllable".
 * 
 * @author Brad Richards
 */
public interface Controllable {
    public void up();
    public void left();
    public void right();
    public void down();
    public void function();
}
