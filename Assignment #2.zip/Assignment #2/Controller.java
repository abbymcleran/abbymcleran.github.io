import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;

/**
 * The Controller class models a simple Controller-driven controller with five
 * buttons and a text display area.  The names of the buttons and the size
 * of the text area can be specified to the constructor.
 *
 * @author Brad Richards
 * @version 1.1
 */

public class Controller implements ActionListener {
    
    private Controllable device;	 // The object we're controlling
    
    private static final int NUM_BUTTONS = 5;
    private JPanel displayPanel; // The panel that holds the display
    private JTextArea display;   // The text display
    private JFrame frame;        // The frame that holds the display and key panels
    private JButton[] buttons;   // All of the buttons

    public static final int NORTH = 0;  
    public static final int SOUTH = 1;  
    public static final int EAST = 2;   
    public static final int WEST = 3;  
    public static final int FUNCTION = 4;

    /**
     * The constructor creates and displays the Controller and prepares it for dealing
     * with button presses.  It takes a string that's used as the window's title.
     *
     * @param device  The object to be device by this GUI
     * @param title  The title to use on the GUI's window 
     * @param vertical  The number of lines of text in the display area
     * @param buttonNames An array of Strings containing names for the buttons
     */
    public Controller(Controllable device, String title, int vertical, String[] buttonNames) {
        // Store the thing being controlled in the field
        this.device = device;
        
        // There are 5 buttons -- four for directions, and one to play
        buttons = new JButton[NUM_BUTTONS];
        if (buttonNames.length != NUM_BUTTONS) {
            throw new IllegalArgumentException("Wrong number of button names!");
        }
        
        // Build the frame holding the Controller components
        frame = new JFrame(title);
        frame.setBackground(Color.LIGHT_GRAY);
        frame.setSize(300,400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        // Display is in a separate panel -- the NORTH panel of border layout
        display = new JTextArea(vertical, 35);
        display.setEditable(false);
        display.setLineWrap(true);
        display.setWrapStyleWord(true);
        display.setFont(new Font("Courier", Font.PLAIN, 13));
        displayPanel = new JPanel();
        displayPanel.add(display);
        display.setText(device.toString());

        // There's a panel in the CENTER of the layout holding the direction keys
        JPanel keys = new JPanel();
        keys.setLayout(new GridLayout(0,3));

        // Create the buttons and register this object as listener for each
        for(int i=0; i<NUM_BUTTONS; i++) {
            buttons[i] = new JButton(buttonNames[i]);
            buttons[i].addActionListener(this);
        }

        // Order is important here.  Interleaving the "boxes" with the
        // buttons gives the proper layout for the buttons on the screen.
        keys.add(Box.createRigidArea(new Dimension(20,20)));
        keys.add(buttons[NORTH]);
        keys.add(Box.createRigidArea(new Dimension(20,20)));
        keys.add(buttons[WEST]);
        keys.add(Box.createRigidArea(new Dimension(20,20)));
        keys.add(buttons[EAST]);
        keys.add(Box.createRigidArea(new Dimension(20,20)));
        keys.add(buttons[SOUTH]);
        keys.add(Box.createRigidArea(new Dimension(20,20)));

        // Add the display and digits panels to the frame
        frame.add(displayPanel, BorderLayout.NORTH);
        frame.add(keys, BorderLayout.CENTER);
        frame.add(buttons[FUNCTION], BorderLayout.SOUTH);
        frame.setVisible(true);
    }

    /**
     * Overwrites the contents of the display (the text window at the top of the Controller)
     * with the String passed in as the parameter to this method.
     * 
     * @param msg The message to be displayed
     */
    public void setText(String msg)
    {
        display.setText(msg);
    }

    /**
     * Returns the contents of the display (the text window at the top of the Controller) as a 
     * String.  It leaves the contents of the display unchanged.
     * 
     * @return  A String containing the contents of the display
     */
    public String getText()
    {
        return display.getText();
    }
    
    /** 
     * This method is called in response to button presses.  You shouldn't ever need to call
     * this yourself.
     * @param e  The event to be handled
     */
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==buttons[NORTH]) {
            device.up();
        } 
        else if (e.getSource()==buttons[SOUTH]) {
            device.down();
        }
        else if (e.getSource()==buttons[EAST]) {
            device.right();
        } 
        else if (e.getSource()==buttons[WEST]) {
            device.left();
        } 
        else if (e.getSource()==buttons[FUNCTION]) {
            device.function();
        } 
        else {
            throw new IllegalArgumentException("Unknown Button Pressed");
        } 
        // After making the move, display the device's toString() output
        // in our text display area.
        setText(device.toString());
    }

}