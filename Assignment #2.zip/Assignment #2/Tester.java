/**
 * The methods in this class will help you test your code.
 */
public class Tester {
    static String[] gameButtons = {"Forward","Back","Right","Left","Hint, please!"};
    static String[] rovButtons = {"North", "South", "East", "West", "Print Total"};

    /**
     * When you're done implementing the ROV, this test class should create
     * instances of both the game, and the ROV, each being controlled by a
     * copy of the remote. You can use this to test their behaviors.
     */
    public static void runControllers()
    {
        AdventureGame game = new AdventureGame();
        Controller gameController = new Controller(game, "Lost in the Dark", 4, gameButtons);

        ROV rover = new ROV();
        Controller rovController = new Controller(rover, "ROV", 4, rovButtons);
    }
    
    /**
     * This class tests out Autopilot's find method on both the game and
     * the ROV. You can test it on the game before getting the ROV working,
     * then come back and uncomment the ROV tests once the ROV is implemented.
     */
    public static void testAutopilot()
    {
      //Uncomment this block to use Autopilot to find the flashlight
         
        //This should always succeed, since the search area is large
        //enough to always include the flashlight.
        AdventureGame game = new AdventureGame();
        Autopilot.find(game, "stumbled", 10, 10);
        
    

      // Uncomment this block to use Autopilot with the ROV
         
        // This call to find should find the 10 at position 6,8
        ROV rover = new ROV();
        Autopilot.find(new ROV(), "10", 15, 15);
        
        // Make a new ROV and try again. This time with a search region
        // that doesn't include a "10".
        rover = new ROV();
        Autopilot.find(new ROV(), "10", 5, 20);
        
    }
}