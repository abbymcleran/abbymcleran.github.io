/**
 * This class models an underwater ROV mapping mineral deposits on the
 * seafloor. The ROV's position can be changed by calling up/down/left/right
 * methods, and the current reading is contained in the result of toString().
 * This class is "preloaded" with data values used for simulated readings on a
 * portion of the seafloor.
 * 
 * @author Brad Richards and Sumneet Brar and Abby McLeran
 * @version 1.0
 */
public class ROV implements Controllable {

    // Here are some fake readings your ROV should pretend to see.
    // This 2D array should be accessed as readings[row][col]. Note
    // that it looks "upside down" compared to the diagram on the
    // assignment since Java requires that we define row 0 first, 
    // then row 1, etc.

    protected int[][] readings = {
            {4, 2, 1, 1, 0, 0, 0, 0, 1},    // This is row 0 (the "bottom" row)
            {8, 5, 3, 1, 0, 0, 0, 1, 0},
            {9, 6, 4, 0, 0, 0, 2, 0, 0},
            {7, 4, 2, 0, 0, 0, 0, 0, 0},
            {4, 2, 0, 0, 0, 1, 0, 2, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 1, 0, 0, 3, 4, 3, 0},
            {0, 0, 0, 0, 1, 7, 9, 7, 2},
            {1, 0, 2, 0, 4, 8, 10, 8, 5},
            {1, 0, 0, 0, 2, 5, 8, 6, 3},
            {0, 0, 0, 0, 0, 2, 3, 4, 2},
            {0, 1, 0, 0, 0, 0, 1, 1, 0}};   // This is row 11 (the "top" row)

    protected int xPos = 0;
    protected int yPos = 0;
    protected int readingTotal;

    /**
     * The constructor initializes the ROV's position, takes a sample reading
     * at the initial position, and ensures that the reading will be returned
     * by toString().
     */
    public ROV() {
        String reading = " "+readings[0][0];
        readingTotal += readings[yPos][xPos];
    }

    /**
     * Move north and take a sample reading.
     */
    public void up() {
        yPos++;
        if (yPos <= readings[0].length){
            readingTotal += readings[yPos][xPos];
        }
    }

    /**
     * Move west and take a sample rading.
     */
    public void left() {
        xPos--;
        if (xPos >= 0){
            readingTotal += readings[yPos][xPos];
        }
    }

    /**
     * Move east and take a sample reading.
     */
    public void right() {
        xPos++;
        if (xPos <= readings.length){
            readingTotal += readings[yPos][xPos];
        }
    }

    /**
     * Move south and take a sample reading.
     */
    public void down() {
        yPos--;
        if (yPos >= 0){
            readingTotal += readings[yPos][xPos];
        }
    }

    /**
     * Print a message reporting the sum of all of the readings taken so far.
     */
    public void function () {
        System.out.println ("Sum of all readings is " + readingTotal);
    }

    /**
     * Return a string containing the most recent sensor reading.
     * 
     * @return Most recent sensor reading, as a string.
     */
    public java.lang.String toString() {
        return " "+readings[yPos][xPos];
    }
}
